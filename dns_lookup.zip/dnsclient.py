#!/usr/bin/python3

"""
    This is a simple dnsclient that supports A, AAAA, MX, SOA, NS and CNAME
    queries written in python.

"""

import sys
import socket
import binascii
import threading

import src.serverconf as serverconf
import src.queryfactory as queryfactory
import src.queryhandler as queryhandler

import pandas as pd
import time

def main():
    """ Main function of the DNS client
    """

    #usage()
    valid_cnt = 0
    list_domain = []
    with open('./unique_domain_list.txt') as f_read:
        for str_line in f_read:
            tokens = str_line.replace('\n', '').split(',')
            list_domain.append((tokens[0], tokens[1]))
    print(len(list_domain), 'domains in list')
    dict_rtype = {}
    dict_resolve = {}
    dict_resolve['domain'] = []
    dict_resolve['class'] = []
    dict_resolve['ttl'] = []
    dict_resolve['rdlength'] = []
    dict_resolve['rdata'] = []

    for (str_domain, str_type) in list_domain:        
        ### Create packet according to the requested query
        packet = ""
        
        query = queryfactory.get_dns_query(str_domain, str_type)
        if query == None:
            # Not Supported Query Type        
            continue

        # query[0] is the packet
        packet = query[0]

        raw_reply = query_dns_server(packet)
        # query[1] is qname length
        reply = queryhandler.parse_answer(raw_reply, query[1])
        #print('[{}] Replied'.format(str_domain))
        dict_rtype['index'] = len(dict_rtype)
        dict_rtype[str_domain] = str(reply.header.rcode)
        valid_cnt += 1

        for entry in reply.answer:
            str_name, dict_answer = queryhandler.parse_anser_entry(entry)
            dict_resolve['index'] = len(dict_resolve)
            dict_resolve['domain'].append(str_name)
            dict_resolve['class'].append(dict_answer['class'])
            dict_resolve['ttl'].append(dict_answer['ttl'])
            dict_resolve['rdlength'].append(dict_answer['rdlength'])
            dict_resolve['rdata'].append(dict_answer['rdata'])
        #queryhandler.print_reply(reply)

        if valid_cnt % 10 == 0:
            print('[', valid_cnt, ']')
            time.sleep(2)

        if valid_cnt % 1000 == 0:
            # Make an intermediate log
            df_rtype = pd.DataFrame(dict_rtype).reset_index()
            df_rtype.to_csv('./dns_result/rtype_{:02d}.csv'.format(int(valid_cnt/1000)))

            df_resolve = pd.DataFrame(dict_resolve).reset_index()
            df_resolve.to_csv('./dns_result/resolve_{:02d}.csv'.format(int(valid_cnt/1000)))
            print('[{}]Log '.format(int(valid_cnt/10000)))
            dict_rtype = {}
            dict_resolve = {}

    # Make an intermediate log
    df_rtype = pd.DataFrame(dict_rtype).reset_index()
    df_rtype.to_csv('./dns_result/rtype_last.csv')

    df_resolve = pd.DataFrame(dict_resolve).reset_index()
    df_resolve.to_csv('./dns_result/resolve_last.csv')
    print('[{}]Log '.format(int(valid_cnt/10000)))
    dict_rtype = {}
    dict_resolve = {}
    return 0

def query_dns_server(packet):
    """ Function used to create a UDP socket, to send the DNS query to the server
        and to receive the DNS reply.

    Args:
        packet = the DNS query message
    
    Returns:
        The reply of the server

    If none of the servers in the dns_servers.conf sends a reply, the program
    exits showing an error message.

    """

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    except socket.error:
        print("[Error]: Faild to create socket. Exiting...")
        exit(1)

    # get DNS server IPs from dns_servers.conf file
    dns_servers = serverconf.read_file()
    # default port for DNS
    server_port = 53

    for server_ip in dns_servers:
        got_response = False

        # send message to server        
        sock.sendto(packet, (server_ip.replace('\n', ''), server_port))
        # receive answer
        recv = sock.recvfrom(1024)

        # if no answer is received, try another server
        if recv:
            got_response = True
            break

    # output error message if no server could respond
    if not got_response:
        print("[Error]: No response received from server. Exiting...")
        exit(0)

    return recv[0]

def usage():
    """ Function that checks if the required arguments are given 
    """

    if len(sys.argv) != 3:
        print("Usage: ./dnsclient.py <DNS name/IP> <query type>")
        exit(0)

if __name__ == "__main__":
    main()
