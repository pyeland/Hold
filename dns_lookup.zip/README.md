# simple dns resolver

A simple DNS client written in python. It supports the following requests: 
- A  
- NS   
- CNAME  
- SOA  
- MX  
- AAAA  

Run it like this:

`./dnsclient www.example.com A`

